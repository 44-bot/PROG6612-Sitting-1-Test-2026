/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author emeris
 */

import java.util.Scanner;

public class Mavenproject2 {

    public static void main(String[] args) {
        String city1 = "Cape Town", city2 = "Port Elizabeth", city3 = "Pretoria";
        String ps1 = "1000", ps2 = "2000", ps3 = "1500";
        String xbox1 = "2000", xbox2 = "3000", xbox3 = "1100";
        String switch1 = "3000", switch2 = "4000", switch3 = "1200";
        
        //Display sales
        System.out.printf("%-15s%-20s%6s\n", "City", "PS5", "Xbox", "Switch");
        System.out.printf("%-15s%-20s%6f\n", city1,ps1,xbox1,switch1);
        System.out.printf("%-15s%-20s%6f\n", city2,ps2,xbox2,switch2);
        System.out.printf("%-15s%-20s%6f\n", city3,ps3,xbox3,switch3);
      
    }
	
        //Totals
    {
    System.out.println("Cape Town       6000");
    System.out.println("Port Elizabeth  9000");
    System.out.println("Pretoria        3800");
    
}
    
        
         
       
        
       
        
                
              
    }
}
